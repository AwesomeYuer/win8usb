Win8USB - Windows 8 USB Installer Maker
by vhanla http://apps.codigobit.info
03/24/2012

This is a utility that will help you make a bootable USB Pendrive 
of Windows 8 installer using its ISO DVD image.

Requirements:
- Windows Vista or superior
- Admin Privileges in order to write USB boot code
- Patience

This tool makes 3 steps
1. Formats your pendrive to NTFS format (REQUIRED)
2. Extracts all files to your USB drive (THIS WILL TAKE LONG TIME!!! VERY LONG TIME)
3. Writes the USB Boot MBR

